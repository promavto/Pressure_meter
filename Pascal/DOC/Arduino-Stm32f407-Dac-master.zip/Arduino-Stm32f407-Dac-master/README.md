# Arduino-Stm32f407-Dac
Dac example for Arduino Core STM32
# Hardware requirements
Generic STM32F407 Development Board.
# Software requirements
STM32 core support for Arduino.
https://github.com/stm32duino/Arduino_Core_STM32
# Supported Pins
PA4 PA5 for GPIOA
